<?php
// Include your database connection file
include_once '../db.php';
// Allow requests from the specified origin
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Methods: POST'); // Allow only POST requests
header('Access-Control-Allow-Headers: Content-Type'); // Allow only Content-Type header

// Check if the request method is OPTIONS (preflight request)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    // Respond with HTTP status code 200 (OK) to preflight requests
    http_response_code(200);
    exit;
}
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve question ID from the POST request
    $requestData = json_decode(file_get_contents('php://input'), true); // Retrieve JSON data
    $questionId = $requestData["questionId"];

    // Prepare and execute the DELETE statement
    $stmt = $conn->prepare("DELETE FROM questions WHERE id = ?");
    $stmt->bind_param("i", $questionId);

    // Check if the statement executed successfully
    if ($stmt->execute()) {
        // If deletion is successful, send a success response
        http_response_code(200); // OK
        echo json_encode(array("message" => "Question deleted successfully"));
    } else {
        // If deletion fails, send an error response
        http_response_code(500); // Internal Server Error
        echo json_encode(array("message" => "Failed to delete question"));
    }

    // Close the statement
    $stmt->close();
} else {
    // If the request method is not POST, return a method not allowed error
    http_response_code(405); // Method Not Allowed
    echo json_encode(array("message" => "Method not allowed"));
}
?>
