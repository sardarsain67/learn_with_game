import React from "react";
import { useNavigate } from "react-router-dom";
import "../assests/css/AdminHome.css";

const AdminHome = () => {
  const navigate = useNavigate();

  const handleCoursesClick = () => {
    // Redirect to /courses page
    navigate("/course");
  };

  const handleQuestionsClick = () => {
    // Redirect to /question page
    navigate("/question");
  };
  const handleCoursesShowClick = () => {
    // Redirect to /question page
    navigate("/courselist");
  };

  return (
    <section className="main">
      <div className="container">
        <h1 className="mb-5 title">Welcome to Admin Panel</h1>
        <div className="row justify-content-center">
          {/* <div className="col-md-4"> */}
          <div className="adminBtn">
            <button
              className="btn btn-primary btn-lg btn-block"
              onClick={handleCoursesClick}
            >
              Courses
            </button>
            {/* </div>
          <div className="col-md-4"> */}
            <button
              className="btn btn-primary btn-lg btn-block"
              onClick={handleCoursesShowClick}
            >
              Show Courses
            </button>
            {/* </div>
          <div className="col-md-4"> */}
            <button
              className="btn btn-primary btn-lg btn-block"
              onClick={handleQuestionsClick}
            >
              Questions
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AdminHome;
