import { useState, useEffect } from "react";
import "../assests/css/profile.css";
import main1 from "../assests/img/main-1.jpg";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import ProgressBar from "react-bootstrap/ProgressBar";
import Badge from "react-bootstrap/Badge";
import "bootstrap/dist/css/bootstrap.min.css";
//import { useNavigate } from "react-router-dom";
//import $ from "jquery"; // Import jQuery

function Profile() {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  //const navigate = useNavigate();

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const authToken = localStorage.getItem("auth-token");
      console.log(authToken);
      if (!authToken) {
        throw new Error("Auth token not found");
      }

      const response = await fetch(
        "http://localhost:80/learning_with_gaming/php/auth/getuser.php",
        {
          method: "POST",
          credentials: "include", // Include credentials
          headers: {
            "Content-Type": "application/json",
            Authorization: localStorage.getItem("auth-token"),
          },
        }
      );

      if (!response.ok) {
        throw new Error("Error fetching user data");
      }

      const userData = await response.json();
      setUserData(userData);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching user data:", error);
      setLoading(false);
    }
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  // Check if userData is null or empty
  if (!userData) {
    return <p>Loading...</p>;
  }

  return (
    <>
      <Container fluid="p-0">
        <section className="profile">
          <img src={main1} alt="" className="profileImage" />
          <div className="profileDetails text-white">
            <h1>My Profile</h1>
            <Row className="mb-3">
              <Col sm={12}>
                <h2>{userData.username}</h2>
              </Col>
            </Row>
            <Row className="mb-3">
              <Col sm={12}>
                <h2>{userData.email}</h2>
              </Col>
            </Row>
          </div>
        </section>
      </Container>

      <Container fluid="p-0">
        <Row className="border p-3">
          <Col sm={6} className="progressContainer">
            <div className="progressSection">
              <h2 className="mt-5">Progress</h2>
              <Row className="mb-3">
                <Col sm={12}>
                  <h4>Module 1 Progress</h4>
                  <ProgressBar
                    now={userData.module1score}
                    label={`${userData.module1score}%`}
                    variant={userData.module1score === 0 ? "danger" : "info"}
                    min={0}
                    max={100}
                  />
                </Col>
              </Row>
              <Row className="mb-3">
                <Col sm={12}>
                  <h4>Module 2 Progress</h4>
                  <ProgressBar
                    now={userData.module2score}
                    label={`${userData.module2score}%`}
                    variant={userData.module2score === 0 ? "danger" : "info"}
                    min={0}
                    max={100}
                  />
                </Col>
              </Row>
              <Row className="mb-3">
                <Col sm={12}>
                  <h4>Module 3 Progress</h4>
                  <ProgressBar
                    now={userData.module3score}
                    label={`${userData.module3score}%`}
                    variant={userData.module3score === 0 ? "danger" : "info"}
                    min={0}
                    max={100}
                  />
                </Col>
              </Row>
              <Row className="mb-3">
                <Col sm={12}>
                  <h4>Final Test Score</h4>
                  <ProgressBar
                    now={userData.finaltestscore}
                    label={`${userData.finaltestscore}%`}
                    variant={userData.finaltestscore === 0 ? "danger" : "info"}
                    min={0}
                    max={100}
                  />
                </Col>
              </Row>
            </div>
          </Col>
          <Col sm={6} className="border-start">
            <div className="badgesSection px-2">
              <h2 className="mt-5">Badges</h2>
              {userData.module1score >= 100 && (
                <Badge bg="dark" className="my-2 mr-2 px-2">
                  Bronze Medal
                </Badge>
              )}
              &nbsp; &nbsp;
              {userData.module2score >= 100 && (
                <Badge bg="secondary" className="my-2 mr-2 px-2">
                  Silver Medal
                </Badge>
              )}
              &nbsp; &nbsp;
              {userData.module3score >= 100 && (
                <Badge bg="warning" className="my-2 mr-2 px-2">
                  Gold Medal
                </Badge>
              )}
              &nbsp; &nbsp;
              {userData.finaltestscore > 70 && (
                <Badge bg="danger">Diamond Medal</Badge>
              )}
            </div>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default Profile;
