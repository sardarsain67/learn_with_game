import { useState, useEffect } from "react";
import Card from "react-bootstrap/Card";
import Table from "react-bootstrap/Table";
import Container from "react-bootstrap/Container";
import "../assests/css/leaderBoard.css";

import { useNavigate } from "react-router-dom";

function LeaderBoard() {
  const navigate = useNavigate();
  const [loggedInUserId, setLoggedInUserId] = useState(null);
  const [leaderboardData, setLeaderboardData] = useState([]);
  const [loggedInUser, setLoggedInUser] = useState({
    rank: 0,
    finaltestscore: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const authToken = localStorage.getItem("auth-token");

    if (!authToken) {
      navigate("/login");
    } else {
      setLoggedInUserId(authToken);
    }
  }, [navigate]);

  useEffect(() => {
    async function fetchLeaderboard() {
      try {
        const authToken = localStorage.getItem("auth-token");

        if (!authToken) {
          console.error("Auth token not found");
          setLoading(false);
          return;
        }

        const response = await fetch(
          "http://localhost:80/learning_with_gaming/php/auth/leaderboard.php",
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              "auth-token": authToken,
            },
          }
        );

        if (!response.ok) {
          console.error("Server error:", response.statusText);
          setLoading(false);
          return;
        }

        const responseData = await response.json(); // Parse response as JSON
        console.log("Fetched leaderboard data:", responseData);

        // Set the leaderboard data
        setLeaderboardData(responseData.leaderboard);

        // Set the logged-in user data or default values if not available
        setLoggedInUser(
          responseData.loggedInUser || { rank: 0, finaltestscore: 0 }
        );

        setLoading(false);
      } catch (error) {
        console.error("Error fetching leaderboard data:", error);
        setLoading(false);
      }
    }

    fetchLeaderboard();
  }, []);

  if (loading) {
    return <p>Loading...</p>; // Display loading message
  }

  if (leaderboardData.length === 0) {
    return <p>No leaderboard data available.</p>; // Display message if no data
  }

  // Filter the top three students based on rank
  const topThreeStudents = leaderboardData.slice(0, 3);

  return (
    <Container fluid="p-0">
      {/* Render top three students */}
      <div className="leader">
        {topThreeStudents.map((item, index) => (
          <Card key={index} style={{ width: "18rem" }} className="cardBody">
            <Card.Body>
              <Card.Title>{item.username}</Card.Title>
              <Card.Text>Rank: {item.rank}</Card.Text>
              <Card.Text>Score: {item.finaltestscore}</Card.Text>
            </Card.Body>
          </Card>
        ))}
      </div>

      {/* Render leaderboard table */}
      <Table striped>
        <thead>
          <tr>
            <th>#</th>
            <th>Username</th>
            <th>Rank</th>
            <th>Score</th>
          </tr>
        </thead>
        <tbody>
          {/* Render the first row with logged-in user data */}
          <tr>
            <td></td>
            <td>You</td>
            <td>{loggedInUser.rank}</td>
            <td>{loggedInUser.finaltestscore}</td>
          </tr>
          {/* Render other leaderboard data */}
          {leaderboardData.map((item, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>{item.username}</td>
              <td>{item.rank}</td>
              <td>{item.finaltestscore}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  );
}

export default LeaderBoard;
