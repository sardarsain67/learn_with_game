import React, { useState, useEffect } from "react";
//import axios from "axios";
//import "../assets/css/Questions.css"; // Import custom CSS file
import "../assests/css/Questions.css";
import { useNavigate } from "react-router-dom";

//import Button from "react-bootstrap/Button";
const Questions = () => {
  const navigate = useNavigate();
  const [showQuestions, setShowQuestions] = useState(false);
  const [addQuestion, setAddQuestion] = useState(false);
  const [questions, setQuestions] = useState([]);
  const [formData, setFormData] = useState({
    question: "",
    options: ["", "", "", ""],
    correctOption: "",
  });

  useEffect(() => {
    const adminAuthToken = localStorage.getItem("adminAuthToken");
    if (!adminAuthToken) {
      // Navigate to the admin home page
      navigate("/admin");
    }
    // Function to fetch questions from the database
    const fetchQuestions = async () => {
      try {
        const response = await fetch(
          "http://localhost:80/learning_with_gaming/php/questions/get_question.php"
        );
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        setQuestions(data); // Assuming the response data is an array of questions
      } catch (error) {
        console.error("Error fetching questions:", error);
      }
    };

    // Call the fetchQuestions function
    fetchQuestions();
  }, []);

  const toggleShowQuestions = () => {
    setShowQuestions(!showQuestions);
    setAddQuestion(false);
  };

  const toggleAddQuestion = () => {
    setAddQuestion(!addQuestion);
    setShowQuestions(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleOptionChange = (e, index) => {
    const newOptions = [...formData.options];
    newOptions[index] = e.target.value;
    setFormData({
      ...formData,
      options: newOptions,
    });
  };

  const handleAddQuestion = async () => {
    try {
      // Send a request to add the new question to the database
      const response = await fetch(
        "http://localhost:80/learning_with_gaming/php/questions/add_question.php",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData), // Send formData containing the new question data
        }
      );

      if (response.ok) {
        // If the question is added successfully, display a success message
        alert("Question added successfully");

        // Update the state with the new question data
        setQuestions([...questions, formData]);

        // Reset the form fields for adding a new question
        setFormData({
          question: "",
          options: ["", "", "", ""],
          correctOption: "",
        });
      } else {
        // If adding the question fails, display an error message
        alert("Failed to add question");
      }
    } catch (error) {
      console.error("Error adding question:", error);
    }
  };

  const handleDeleteQuestion = async (questionId) => {
    // Show confirmation dialog to confirm deletion
    const confirmed = window.confirm(
      "Are you sure you want to delete this question?"
    );

    // If user confirms deletion
    if (confirmed) {
      try {
        const response = await fetch(
          "http://localhost:80/learning_with_gaming/php/questions/delete_question.php",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ questionId }),
          }
        );

        if (response.ok) {
          // If question is deleted successfully, show an alert message
          alert("Question deleted successfully");

          // Refresh the page to update the list of questions
          window.location.reload(); // This will reload the entire page
        } else {
          // If deletion fails, show an error message
          alert("Failed to delete question");
        }
      } catch (error) {
        console.error("Error deleting question:", error);
      }
    }
  };

  //   const handleLogout = async () => {
  //     try {
  //       const response = await fetch(
  //         "http://localhost:80/learning_with_gaming/php/auth/logout.php",
  //         {
  //           method: "POST",
  //           body: new FormData(), // No need to pass any data since it's just a logout request
  //         }
  //       );

  //       // Check if the status code indicates success (2xx range)
  //       if (response.ok) {
  //         // Clear local storage
  //         localStorage.clear();

  //         // Redirect to root path
  //         navigate("/");
  //       } else {
  //         // Handle non-successful responses
  //         console.error("Logout failed:", response.statusText);
  //       }
  //     } catch (error) {
  //       console.error("Error logging out:", error);
  //     }
  //   };

  return (
    <div>
      <section className="questionMain">
        <div>
          <p className="quesContent">
            In today's interconnected digital landscape, cybersecurity stands as
            a paramount concern for individuals and organizations alike.
          </p>
        </div>
        <div className="buttons-container">
          {" "}
          {/* Wrap buttons in a container */}
          <button
            className="btn btn-primary mx-2"
            onClick={toggleShowQuestions}
          >
            Show Questions
          </button>
          <button className="btn btn-primary" onClick={toggleAddQuestion}>
            Add Question
          </button>
        </div>
      </section>
      {showQuestions && (
        <div>
          <h2>All Questions</h2>
          <table className="table table-bordered table-striped">
            {" "}
            {/* Add Bootstrap classes to table */}
            <thead>
              <tr>
                <th>Question ID</th>
                <th>Question</th>
                <th>Options</th>
                <th>Correct Option</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {questions.map((question, index) => (
                <tr key={index}>
                  <td>{question.id}</td>
                  <td>{question.question}</td>
                  <td>
                    <ul
                      style={{
                        listStyleType: "decimal",
                        listStylePosition: "inside",
                      }}
                    >
                      {question.options.map((option, i) => (
                        <li key={i}>{option}</li>
                      ))}
                    </ul>
                  </td>
                  <td>{question.answer}</td>
                  <td>
                    <button
                      className="btn btn-danger"
                      onClick={() => handleDeleteQuestion(question.id)}
                    >
                      {" "}
                      {/* Add Bootstrap class */}
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {addQuestion && (
        <section className="addQuestionMain">
          <div className="d-flex justify-content-center">
            {" "}
            {/* Center the form horizontally */}
            <div className="custom-form-container">
              {" "}
              {/* Apply custom width */}
              <h2 style={{ textAlign: "center" }}>Add Question</h2>
              <form>
                <div className="form-group">
                  <label>Question:</label>
                  <input
                    type="text"
                    className="form-control"
                    name="question"
                    value={formData.question}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Options:</label>
                  {formData.options.map((option, index) => (
                    <div
                      key={index}
                      className="form-group"
                      style={{ marginBottom: "10px" }}
                    >
                      <label>{1 + index}</label>
                      <input
                        type="text"
                        className="form-control"
                        value={option}
                        onChange={(e) => handleOptionChange(e, index)}
                        required
                      />
                    </div>
                  ))}
                </div>

                <div className="form-group">
                  <label>Correct Option:</label>
                  <select
                    className="form-control"
                    name="correctOption"
                    value={formData.correctOption}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Select Correct Option</option>
                    {[1, 2, 3, 4].map((option) => (
                      <option key={option} value={option}>
                        Option {option}
                      </option>
                    ))}
                  </select>
                </div>
                <button
                  className="btn btn-primary my-2"
                  type="button"
                  onClick={handleAddQuestion}
                >
                  Add Question
                </button>
              </form>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

export default Questions;
