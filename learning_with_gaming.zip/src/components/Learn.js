import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import Card from "react-bootstrap/Card";
import Button from "react-bootstrap/Button";
import "../assests/css/learn.css";

function Learn() {
  const { courseId } = useParams();
  const [courseDetails, setCourseDetails] = useState(null);
  const [currentModuleIndex, setCurrentModuleIndex] = useState(null);
  const [currentContentIndex, setCurrentContentIndex] = useState(0);

  useEffect(() => {
    async function fetchCourseDetails() {
      try {
        const response = await fetch(
          `http://localhost:80/learning_with_gaming/php/admin/course/get_course_details.php?courseId=${courseId}`
        );
        if (!response.ok) {
          throw new Error("Failed to fetch course details");
        }
        const data = await response.json();
        setCourseDetails(data);
      } catch (error) {
        console.error("Error fetching course details:", error);
      }
    }

    fetchCourseDetails();
  }, [courseId]);

  const handleStartLearn = (index) => {
    setCurrentModuleIndex(index);
    setCurrentContentIndex(0);
  };

  const handleNextContent = () => {
    if (courseDetails && currentModuleIndex !== null) {
      const currentModule = courseDetails.modules[currentModuleIndex];

      if (currentContentIndex < currentModule.contents.length - 1) {
        setCurrentContentIndex((prevIndex) => prevIndex + 1);
      } else {
        // Continue to the next module
        if (currentModuleIndex < courseDetails.modules.length - 1) {
          setCurrentModuleIndex((prevIndex) => prevIndex + 1);
          setCurrentContentIndex(0);
          congratulateUser(currentModuleIndex + 1); // Congratulate the user for completing the module
          updateScore(currentModuleIndex + 1, 100); // Update score for the completed module
        } else {
          // Display congratulation message for completing the course
          alert("Congratulations! You have completed this course.");
          // Update score for the last module
          updateScore(currentModuleIndex + 1, 100); // Assuming the score is 100 for completing the last module
        }
      }
    }
  };

  const congratulateUser = (moduleIndex) => {
    alert(`Congratulations! You have completed Module ${moduleIndex}.`);
  };

  const updateScore = async (module, score) => {
    const authToken = localStorage.getItem("auth-token");
    const requestData = {
      module,
      score,
    };

    console.log("Request Data:", requestData); // Log the data being sent

    try {
      const response = await fetch(
        "http://localhost:80/learning_with_gaming/php/score/update_score.php",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: authToken,
          },
          body: JSON.stringify(requestData),
        }
      );
      if (!response.ok) {
        throw new Error("Failed to update score");
      }
    } catch (error) {
      console.error("Error updating score:", error);
    }
  };

  return (
    <section className="learnMain">
      <div className="container mt-4">
        {courseDetails ? (
          <div>
            <div>
              <h1
                style={{
                  fontWeight: "bold",
                  color: "#fff",
                  textAlign: "center",
                }}
              >
                {courseDetails.title}
              </h1>
              <p style={{ fontWeight: "bold", color: "#fff" }}>
                Overview of the course: {courseDetails.description}
              </p>
            </div>
            {currentModuleIndex === null ? (
              // Display module cards
              <div>
                {courseDetails.modules.map((module, index) => (
                  <Card key={index} className="mb-4">
                    <Card.Header>{module.moduleName}</Card.Header>
                    <Card.Body>
                      <Card.Text>{module.shortDescription}</Card.Text>
                      <Button
                        variant="primary"
                        onClick={() => handleStartLearn(index)}
                      >
                        Start Learn
                      </Button>
                    </Card.Body>
                  </Card>
                ))}
              </div>
            ) : (
              // Display module content
              <Card className="mb-4">
                <Card.Header>
                  {courseDetails.modules[currentModuleIndex].moduleName}
                </Card.Header>
                <Card.Body>
                  <Card.Title>
                    {
                      courseDetails.modules[currentModuleIndex].contents[
                        currentContentIndex
                      ].heading
                    }
                  </Card.Title>
                  <Card.Text>
                    {
                      courseDetails.modules[currentModuleIndex].contents[
                        currentContentIndex
                      ].content
                    }
                  </Card.Text>
                  <Button variant="primary" onClick={handleNextContent}>
                    Next
                  </Button>
                </Card.Body>
              </Card>
            )}
          </div>
        ) : (
          <p>Loading course details...</p>
        )}
      </div>
    </section>
  );
}

export default Learn;
