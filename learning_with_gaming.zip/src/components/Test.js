import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import TestResult from "./TestResult";
import "../assests/css/test.css";

function Test() {
  const navigate = useNavigate();
  const [testData, setTestData] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [clickedOption, setClickedOption] = useState(0);
  const [answerSubmitted, setAnswerSubmitted] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        const authToken = localStorage.getItem("auth-token");
        const response = await fetch(
          "http://localhost:80/learning_with_gaming/php/questions/get_question.php",
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              Authorization: authToken,
            },
          }
        );
        if (!response.ok) {
          throw new Error("Failed to fetch questions");
        }
        const questionsData = await response.json();
        setTestData(questionsData); // Set the fetched questions data to the state
      } catch (error) {
        console.error("Error fetching questions:", error);
        navigate("/login");
      }
    };

    fetchQuestions();
  }, [navigate]);

  const changeQuestion = () => {
    if (answerSubmitted) {
      updateScore();
      if (currentQuestionIndex < testData.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setClickedOption(0);
        setAnswerSubmitted(false);
      } else {
        setShowResult(true);
      }
    } else {
      setAnswerSubmitted(true);
    }
  };

  const isOptionCorrect = (optionIndex) => {
    return optionIndex + 1 === testData[currentQuestionIndex]?.answer;
  };

  const updateScore = () => {
    if (clickedOption === testData[currentQuestionIndex]?.answer) {
      setScore(score + 1);
    }
  };

  return (
    <div>
      <p className="headingTitle">Test</p>
      <div className="testBox">
        {showResult ? (
          <TestResult
            score={score}
            totalScore={testData.length}
            testData={testData}
          />
        ) : (
          <>
            <div className="question">
              <span id="quesNumber">{currentQuestionIndex + 1}</span>
              <span id="question-txt">
                {testData[currentQuestionIndex]?.question}
              </span>
            </div>
            <div className="optionContainer">
              {testData[currentQuestionIndex]?.options?.map((option, index) => {
                const isCorrect = isOptionCorrect(index);
                const isSelected = clickedOption === index + 1;
                return (
                  <button
                    key={index}
                    className={`optionBtn ${isSelected ? "selected" : ""} ${
                      answerSubmitted ? (isCorrect ? "correct" : "wrong") : ""
                    }`}
                    onClick={() => {
                      if (!answerSubmitted) {
                        setClickedOption(index + 1);
                      }
                    }}
                    disabled={answerSubmitted}
                  >
                    {option}
                  </button>
                );
              })}
            </div>
            <input
              type="button"
              value={answerSubmitted ? "Next" : "Submit"}
              id="nextButton"
              onClick={changeQuestion}
              disabled={!clickedOption && !answerSubmitted}
              className="nextBtnDisabled"
            />
          </>
        )}
      </div>
    </div>
  );
}

export default Test;
